﻿using System;

namespace RSP_GS_MAINTAIN_BUILDING_FLOORResources
{
    public class Resources_Dummy_Class
    {

    }
}
