﻿using System;

namespace RSP_GS_MAINTAIN_BUILDINGResources
{
    public class Resources_Dummy_Class
    {

    }
}
