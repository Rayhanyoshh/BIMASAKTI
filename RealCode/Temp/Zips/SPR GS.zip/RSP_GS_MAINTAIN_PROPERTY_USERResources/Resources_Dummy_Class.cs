﻿using System;

namespace RSP_GS_MAINTAIN_PROPERTY_USERResources
{
    public class Resources_Dummy_Class
    {

    }
}
