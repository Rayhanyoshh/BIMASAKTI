﻿using System;

namespace RSP_ACTIVITY_VALIDITYResources
{
    public class Resources_Dummy_Class
    {

    }
}
