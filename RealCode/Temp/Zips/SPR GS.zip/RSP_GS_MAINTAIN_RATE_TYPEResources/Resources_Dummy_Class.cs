﻿using System;

namespace RSP_GS_MAINTAIN_RATE_TYPEResources
{
    public class Resources_Dummy_Class
    {

    }
}
