﻿using System;

namespace RSP_GS_MAINTAIN_TRANS_CODE_APPROVERResources
{
    public class Resources_Dummy_Class
    {

    }
}
