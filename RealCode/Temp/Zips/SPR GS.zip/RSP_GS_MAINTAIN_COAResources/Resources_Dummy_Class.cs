﻿using System;

namespace RSP_GS_MAINTAIN_COAResources
{
    public class Resources_Dummy_Class
    {

    }
}
