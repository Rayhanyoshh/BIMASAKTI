﻿using System;

namespace RSP_GS_MAINTAIN_CURRENCY_RATEResources
{
    public class Resources_Dummy_Class
    {

    }
}
