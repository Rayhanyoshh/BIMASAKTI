﻿using System;

namespace RSP_GS_MAINTAIN_CENTERResources
{
    public class Resources_Dummy_Class
    {

    }
}
