﻿using System;

namespace RSP_GS_MAINTAIN_BUILDING_UNITResources
{
    public class Resources_Dummy_Class
    {

    }
}
