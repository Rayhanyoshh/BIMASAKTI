﻿using System;

namespace RSP_GS_VALIDATE_USER_ACT_APPRResources
{
    public class Resources_Dummy_Class
    {

    }
}
