﻿using System;

namespace RSP_GS_MAINTAIN_CURRENCYResources
{
    public class Resources_Dummy_Class
    {

    }
}
