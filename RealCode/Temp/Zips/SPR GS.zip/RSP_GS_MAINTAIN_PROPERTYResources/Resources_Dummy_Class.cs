﻿using System;

namespace RSP_GS_MAINTAIN_PROPERTYResources
{
    public class Resources_Dummy_Class
    {

    }
}
