﻿using System;

namespace RSP_GS_MAINTAIN_UNIT_VIEWResources
{
    public class Resources_Dummy_Class
    {

    }
}
