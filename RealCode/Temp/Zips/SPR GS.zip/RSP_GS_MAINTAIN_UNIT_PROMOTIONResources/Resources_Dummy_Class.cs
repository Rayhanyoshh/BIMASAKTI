﻿using System;

namespace RSP_GS_MAINTAIN_UNIT_PROMOTIONResources
{
    public class Resources_Dummy_Class
    {

    }
}
