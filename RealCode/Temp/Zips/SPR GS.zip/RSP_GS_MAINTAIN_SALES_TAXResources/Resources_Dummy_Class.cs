namespace RSP_GS_MAINTAIN_SALES_TAXResources
{
    public class Resources_Dummy_Class
    {
        
    }
}