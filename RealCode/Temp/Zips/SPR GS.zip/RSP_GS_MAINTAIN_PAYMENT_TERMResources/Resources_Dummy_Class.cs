﻿using System;

namespace RSP_GS_MAINTAIN_PAYMENT_TERMResources
{
    public class Resources_Dummy_Class
    {

    }
}
