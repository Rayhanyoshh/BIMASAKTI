﻿using System;

namespace RSP_GS_MAINTAIN_WITHHOLDING_TAXResources
{
    public class Resources_Dummy_Class
    {

    }
}
