﻿using System;

namespace RSP_GS_MAINTAIN_OTHER_CHARGESResources
{
    public class Resources_Dummy_Class
    {

    }
}
