﻿using System;

namespace RSP_GS_MAINTAIN_CASH_BANKResources
{
    public class Resources_Dummy_Class
    {

    }
}
